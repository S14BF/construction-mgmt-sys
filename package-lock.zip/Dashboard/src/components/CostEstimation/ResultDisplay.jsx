import React from "react";
import "./CostEstimation.css";
import CostBreakdownChart from "./CostBreakdownChart";

const ResultDisplay = ({ result, contributions }) => {
  return (
    <div className="result-display">
      <h2>Result</h2>
      <p>Predicted Cost: {result} INR</p>
      <h3>Cost Breakdown</h3>
      {contributions && <CostBreakdownChart data={contributions} />}

      </div>
  );
};

export default ResultDisplay;
