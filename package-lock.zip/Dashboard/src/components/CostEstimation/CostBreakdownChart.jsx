import React, { useRef } from 'react';
import { Pie } from 'react-chartjs-2';
import 'chart.js/auto';
import html2canvas from 'html2canvas';
import './CostBreakdownChart.css';

const CostBreakdownChart = ({ data, totalCost, containerRef }) => {
  const labels = Object.keys(data);
  const values = Object.values(data);
  const colors = [
    '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40',
    '#E74C3C', '#3498DB', '#F1C40F', '#1ABC9C', '#9B59B6', '#F39C12', '#D2691E'
  ];

  const chartData = {
    labels: labels,
    datasets: [
      {
        data: values,
        backgroundColor: colors,
        hoverOffset: 4
      },
    ],
  };

  const options = {
    plugins: {
      legend: {
        display: false,
      },
    },
  };

  const downloadImage = () => {
    if (containerRef.current) {
      html2canvas(containerRef.current, { scale: 2 }).then((canvas) => {
        const link = document.createElement('a');
        link.download = 'cost_estimation_snapshot.png';
        link.href = canvas.toDataURL('image/png');
        link.click();
      });
    }
  };

  return (
    <div className="chart-container">
      <h2 className="total-cost">Total Estimated Cost: {totalCost.toFixed(2)} INR</h2>
      <div className="field-list">
        <ul>
          {labels.map((label, index) => (
            <li key={index}>
              <div className="field-color" style={{ backgroundColor: colors[index] }}></div>
              {label} - {values[index].toFixed(2)} INR
            </li>
          ))}
        </ul>
      </div>
      <div className="chart-wrapper">
        <Pie data={chartData} options={options} />
      </div>
      <button className="download-btn" onClick={downloadImage}>
        Download Snapshot
      </button>
    </div>
  );
};

export default CostBreakdownChart;