from flask import Blueprint, request, jsonify
import mysql.connector
from mysql.connector import Error
from flask_cors import CORS  # Import flask_cors

project_bp = Blueprint('project', __name__)
CORS(project_bp)  # Enable CORS for all routes

# Database connection setup (modify with your database credentials)
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",  # Your DB host
        user="root",       # Your DB user
        password="",  # Your DB password
        database="construction_mgmt"  # Your DB name
    )

@project_bp.route('/projects_list', methods=['GET'])
def projects_list():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = "SELECT project_id, project_name, location, start_date, end_date FROM projects"
        cursor.execute(query)
        projects = cursor.fetchall()

    

        project_list = [
            {
                "project_id": project[0],
                 "project_name": project[1].title() if project[1] else "", 
                "location": project[2].capitalize() if project[2] else"",
                "start_date": project[3],
                "end_date": project[4]
            }
            for project in projects
        ]
        return jsonify(project_list)
    except Error as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

# Endpoint to get details of a specific project
@project_bp.route('/project_details', methods=['GET'])
def get_project_details():
    project_id = request.args.get('project')
    if not project_id:
        return jsonify({"message": "Project ID is required"}), 400

    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM projects WHERE project_id = %s", (project_id,))
        project = cursor.fetchone()
        
        if not project:
            return jsonify({"message": "Project not found"}), 404
        
        if 'project_name' in project and project['project_name']:
            project['project_name'] = project['project_name'].title()
        
        # Format start_date and end_date properly
        if 'start_date' in project and project['start_date']:
            project['start_date'] = project['start_date'].strftime('%d-%m-%Y')  # Format as DD-MM-YYYY

        if 'end_date' in project and project['end_date']:
            project['end_date'] = project['end_date'].strftime('%d-%m-%Y')  # Format as DD-MM-YYYY

        
        return jsonify(project)
    except Exception as e:
        return jsonify({"message": "Error fetching project details", "error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

# Endpoint to update the project details
@project_bp.route('/update_project/<int:project_id>', methods=['PUT'])
def update_project(project_id):
    try:
        project_data = request.get_json()
        project_name = project_data['project_name']
        location = project_data['location']
        project_type = project_data['project_type']
        sponsor = project_data['sponsor']
        budget = project_data['budget']
        project_area = project_data['project_area']
        start_date = project_data['start_date']
        end_date = project_data['end_date']
        
        conn = get_db_connection()
        cursor = conn.cursor()
        query = """
            UPDATE projects
            SET project_name = %s, location = %s, project_type = %s, sponsor = %s,
                budget = %s, project_area = %s, start_date = %s, end_date = %s
            WHERE project_id = %s
        """
        cursor.execute(query, (project_name, location, project_type, sponsor, budget, project_area, start_date, end_date, project_id))
        conn.commit()
        
        return jsonify({"message": "Project updated successfully!"})
    except Error as e:
        return jsonify({"message": "Error updating project", "error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

# Endpoint to add a new project
@project_bp.route('/schedule/add_project', methods=['POST'])
def add_project():
    try:
        # Step 1: Add the project
        project_data = request.get_json()
        project_name = project_data['project_name']
        location = project_data['location']
        project_type = project_data['project_type']
        sponsor = project_data['sponsor']
        budget = project_data['budget']
        project_area = project_data['project_area']
        start_date = project_data['start_date']
        end_date = project_data['end_date']

        conn = get_db_connection()
        cursor = conn.cursor()
        add_project_query = """
            INSERT INTO projects (project_name, location, project_type, sponsor, budget, 
                                  project_area, start_date, end_date)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(add_project_query, (project_name, location, project_type, sponsor, budget, project_area, start_date, end_date))
        project_id = cursor.lastrowid  # Get the newly created project_id

        # Step 2: Add tasks for the project
        add_tasks_query = """
            INSERT INTO tasks (project_id, task_name, phase)
            SELECT %s, task_name, phase
            FROM task_templates
        """
        cursor.execute(add_tasks_query, (project_id,))
        conn.commit()
        
        return jsonify({"message": "Project and tasks added successfully!"})
    except Error as e:
        return jsonify({"message": "Error adding project and tasks", "error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

@project_bp.route('/delete_task/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM tasks WHERE task_id = %s", (task_id,))
        conn.commit()

        if cursor.rowcount == 0:
            return jsonify({"message": "Task not found"}), 404

        return jsonify({"message": "Task deleted successfully!"}), 200
    except Error as e:
        return jsonify({"message": "Error deleting task", "error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()



@project_bp.route('/tasks/<int:project_id>', methods=['GET'])
def get_project_tasks(project_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tasks WHERE project_id = %s", (project_id,))
        tasks = cursor.fetchall()
        return jsonify(tasks)
    except Error as e:
        return jsonify({"message": "Error fetching tasks", "error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

# Endpoint to delete a project
@project_bp.route('/delete_project/<int:project_id>', methods=['DELETE'])
def delete_project(project_id):
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            # Delete related tasks first
            cursor.execute("DELETE FROM tasks WHERE project_id = %s", (project_id,))
            # Delete the project
            cursor.execute("DELETE FROM projects WHERE project_id = %s", (project_id,))
            conn.commit()

            if cursor.rowcount == 0:
                return jsonify({"message": "Project not found"}), 404

            return jsonify({"message": "Project deleted successfully!"}), 200
    except Exception as e:
        print(f"Error while deleting project: {e}")  # Log the error
        return jsonify({"error": "An unexpected error occurred"}), 500
    finally:
        if conn:
            conn.close()


# Endpoint to fetch the status of a project (tasks and completion percentage)
# Endpoint to fetch the status of a project (tasks and completion percentage)
@project_bp.route('/project_status/<int:project_id>', methods=['GET'])
def get_project_status(project_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Fetch tasks related to the project
        cursor.execute("SELECT task_id, task_name, phase, completed FROM tasks WHERE project_id = %s", (project_id,))
        tasks = cursor.fetchall()

        if not tasks:
            return jsonify({"message": "No tasks found for this project"}), 404

        # Calculate completion percentage
        completed_tasks = sum([1 for task in tasks if task['completed']])
        total_tasks = len(tasks)
        completion_percentage = round((completed_tasks / total_tasks) * 100, 2) if total_tasks > 0 else 0.0

        task_list = [{"task_id": task['task_id'], "task_name": task['task_name'], "phase": task['phase'], "completed": task['completed']} for task in tasks]

        return jsonify({
            "tasks": task_list,
            "completion_percentage": completion_percentage
        })

    except Error as e:
        return jsonify({"message": "Error fetching project status", "error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()


# Endpoint to update the completion status of a task
@project_bp.route('/update_task/<int:task_id>', methods=['PUT'])
def update_task_status(task_id):
    try:
        task_data = request.get_json()
        completed = task_data['completed']

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE tasks SET completed = %s WHERE task_id = %s", (completed, task_id))
        conn.commit()

        return jsonify({"message": "Task status updated successfully!"})
    except Error as e:
        return jsonify({"message": "Error updating task status", "error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

@project_bp.route('/add_task', methods=['POST'])
def add_task():
    try:
        # Extract task data from the request
        task_data = request.get_json()
        project_id = task_data['project_id']
        task_name = task_data['task_name']
        phase = task_data['phase']

        # Establish database connection
        conn = get_db_connection()
        cursor = conn.cursor()

        # Insert the new task into the `tasks` table
        query = """
            INSERT INTO tasks (project_id, task_name, phase, completed)
            VALUES (%s, %s, %s, %s)
        """
        cursor.execute(query, (project_id, task_name, phase, False))  # By default, `completed` is set to `False`
        conn.commit()

        return jsonify({"message": "Task added successfully!"}), 201
    except Error as e:
        return jsonify({"message": "Error adding task", "error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()




if __name__ == '__main__':
    project_bp.run(debug=True)
