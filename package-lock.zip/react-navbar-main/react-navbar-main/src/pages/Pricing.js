export default function Pricing() {
  return <h1>Pricing</h1>
}
